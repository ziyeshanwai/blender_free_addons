# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

import bpy
import mathutils

if "bpy" in locals():
    pass
else:
    pass


def get_location_local(self):
    return self.matrix_local.to_translation()


def set_location_local(self, value):
    current_local_location = self.matrix_local.to_translation()
    diff_location = mathutils.Vector(value) - current_local_location
    if self.parent:
        if self.parent_type == 'OBJECT':
            orient_matrix = self.parent.matrix_world.to_3x3()
        elif self.parent_type == 'VERTEX':
            vertex_index = self.parent_vertices[0]
            vertex = self.parent.data.vertices[vertex_index]
            vertex_co_global = self.parent.matrix_world.to_3x3().inverted() @ vertex.co
            orient_matrix = mathutils.Matrix.Translation(vertex_co_global).to_3x3()
        elif self.parent_type == 'VERTEX_3':
            v1 = self.parent.data.vertices[self.parent_vertices[0]].co
            v2 = self.parent.data.vertices[self.parent_vertices[1]].co
            v3 = self.parent.data.vertices[self.parent_vertices[2]].co
            vcenter = (v1 + v2 + v3) / 3
            va = v2 - v1
            vb = v3 - v1
            vc = va.cross(vb)
            if vc.magnitude > 0:
                vc = vc.normalized()
            else:
                #TODO A B C are colinear, what now?
                pass

            vb2 = vc.cross(va).normalized()
            va2 = va.normalized()
            rotation_matrix = mathutils.Matrix([va2, vb2, vc]).transposed()
            vertex_matrix = (
                mathutils.Matrix.Translation(v1) @ rotation_matrix.to_4x4()
            ).to_3x3()
            orient_matrix = self.parent.matrix_world.to_3x3().inverted() @ vertex_matrix
        elif self.parent_type == 'BONE':
            armature = self.parent
            pose_bone = armature.pose.bones[self.parent_bone]
            orient_matrix = (self.parent.matrix_world.inverted() @ pose_bone.matrix).to_3x3()
        else:
            orient_matrix = self.parent.matrix_world.to_3x3()
    else:
        orient_matrix = self.matrix_world.to_3x3()

    bpy.ops.transform.translate(
        value=diff_location,
        orient_type='LOCAL',
        orient_matrix=orient_matrix,
        orient_matrix_type='LOCAL',
        use_accurate=True
    )


def get_location_world(self):
    return self.matrix_world.to_translation()


def set_location_world(self, value):
    for i in range(0, 3):
        self.matrix_world[i][3] = value[i]


def register_props():
    bpy.types.Object.location_local = bpy.props.FloatVectorProperty(
        name="Location Local",
        subtype='TRANSLATION',
        precision=5,
        options={'HIDDEN'},
        set=set_location_local,
        get=get_location_local
    )

    bpy.types.Object.location_world = bpy.props.FloatVectorProperty(
        name="Location World",
        subtype='TRANSLATION',
        precision=5,
        options={'HIDDEN'},
        set=set_location_world,
        get=get_location_world

    )

def unregister_props():
    pass
