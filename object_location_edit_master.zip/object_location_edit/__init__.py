# File: __init__.py
# Needed for python to register this folder as a module and for blender to register/unregister the addon.

# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

# Variable: bl_info
# Contains informations for Blender to recognize and categorize the addon.
bl_info = {
    "name": "Object location edit",
    "author": "Ondrej Brinkel",
    "version": (0, 0, 1),
    "blender": (2, 80, 0),
    "description": "Adds editing of local and global object coordinates in the UI.",
    "warning": "",
    "wiki_url": "https://gitlab.com/blender3d/addon-object-location-edit/-/wiki_pages/home",
    "tracker_url": "https://gitlab.com/blender3d/addon-object-location-edit/issues",
    "category": "Interface"
}

if "bpy" in locals():
    from importlib import reload
    ui_panels = reload(ui_panels)
    props = reload(props)
else:
    from object_location_edit import ui_panels, props

import bpy

# Function: register
# Registers the addon with all its classes and the menu function.
def register():
    ui_panels.register_ui_panels()
    props.register_props()

# Function: unregister
# Unregisters the addon and all its classes and removes the entry from the menu.
def unregister():
    ui_panels.unregister_ui_panels()
    props.unregister_props()

if __name__ == "__main__":
    register()
